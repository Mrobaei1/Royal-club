بسته اتصال صفحه تخته‌نرد به پروژه Royal Club

این بسته فایل‌ها را در مسیرهای متناظر پروژه قرار می‌دهد:
- apps/mobile/lib/main.dart (صفحه اصلی به‌روزشده؛ کاشی شطرنج و کارت‌ها حفظ شده‌اند)
- apps/mobile/lib/backgammon_engine.dart (موتور محلی)
- apps/mobile/lib/engine_backgammon_screen.dart (رابط بازی)
- apps/mobile/test/backgammon_engine_test.dart (تست‌های موتور)

مهم: این بسته هنوز در مخزن GitHub شما ثبت نشده است؛ اتصال GitHub در این گفتگو اجازه نوشتن نداد.
پس از انتقال فایل‌ها به پروژه، از مسیر apps/mobile اجرا کنید:
flutter analyze
flutter test

این نسخه بازی محلی است، نه بازی آنلاین دونفره. برای انتشار واقعی باید موتور قوانین جداگانه بازبینی و تست شود.
